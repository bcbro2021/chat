import threading
import socket

IP = '127.0.0.1'
PORT = 59000
with open("server.conf") as conf:
    data = conf.readlines()
    for line in data:
        if line.startswith("IP:"):
            IP = line.split(":")[1].strip()
        elif line.startswith("PORT:"):
            PORT = int(line.split(":")[1].strip())
print(IP,PORT)
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((IP, PORT))
server.listen()
clients = []
aliases = []


def broadcast(message):
    for client in clients:
        client.send(message)

# Function to handle clients'connections


def handle_client(client):
    while True:
        try:
            message = client.recv(1024)
            broadcast(message)
        except:
            index = clients.index(client)
            clients.remove(client)
            client.close()
            alias = aliases[index]
            broadcast(f'{alias} has left the chat room!'.encode('utf-8'))
            aliases.remove(alias)
            break
# Main function to receive the clients connection


def receive():
    while True:
        # server running
        print('Server is running and listening ...')
        client, address = server.accept()

        # connection established
        print(f'connection is established with {str(address)}')

        # checking alias
        client.send('alias?'.encode('utf-8'))
        alias = client.recv(1024).decode()
        aliases.append(alias)
        clients.append(client)

        # global announcement
        print(f'username of {address} is {alias}')
        broadcast(f'{alias} has connected to the chat room'.encode("utf-8"))
        client.send('you are now connected!'.encode('utf-8'))
        thread = threading.Thread(target=handle_client, args=(client,))
        thread.start()


if __name__ == "__main__":
    receive()