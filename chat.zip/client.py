import threading
import socket
import sys
alias = input('Username: ')

PORT = int(sys.argv[2])
IP = sys.argv[1]

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((IP, PORT))


def client_receive():
    while True:
        try:
            message = client.recv(1024).decode('utf-8')
            if message == "alias?":
                client.send(alias.encode('utf-8'))
            else:
                print(f"{message}\n")
        except:
            print('Error!')
            client.close()
            break


def client_send():
    while True:
        Input = input(">> ")
        message = f'{alias}: {Input}'
        client.send(message.encode('utf-8'))


receive_thread = threading.Thread(target=client_receive)
receive_thread.start()

send_thread = threading.Thread(target=client_send)
send_thread.start()