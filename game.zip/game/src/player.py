import pygame

class Player():
    def __init__(self,id,x,y,w,h):
        # size and loc
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.id = id
        self.rect = pygame.Rect(self.x,self.y,self.w,self.h)

        # movement
        self.movement = [0,0]
        self.moveleft = False
        self.moveright = False
        self.moveup = False
        self.movedown = False
        self.speed = 4
    def update(self):
        self.rect.x = self.x
        self.rect.y = self.y

        # key press detect
        self.movement = [0,0]
        if self.moveleft:
            self.movement[0] -= self.speed
        if self.moveright:
            self.movement[0] += self.speed
        if self.moveup:
            self.movement[1] -= self.speed
        if self.movedown:
            self.movement[1] += self.speed

        # movement
        self.x += self.movement[0]
        self.y += self.movement[1]

    def draw(self,win,color):
        pygame.draw.rect(win,color,self.rect)
    def events(self,event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                self.moveleft = True
            if event.key == pygame.K_d:
                self.moveright = True
            if event.key == pygame.K_s:
                self.movedown = True
            if event.key == pygame.K_w:
                self.moveup = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                self.moveleft = False
            if event.key == pygame.K_d:
                self.moveright = False
            if event.key == pygame.K_s:
                self.movedown = False
            if event.key == pygame.K_w:
                self.moveup = False
