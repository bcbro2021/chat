import pickle
import threading
import socket
import pygame
from pygame.locals import *
import src
import sys

alias = input('Choose an alias >>> ')
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 59000))

# client
WIN_SIZE = (800,600)
TITLE = "HELLO"
win = pygame.display.set_mode(WIN_SIZE)
pygame.display.set_caption(TITLE)

player = src.Player(alias,20,20,20,20)
players = []

def client_receive():
    while True:
        try:
            message = pickle.loads(client.recv(4096))
            if message in players:
                players.remove(message)
            players.append(message)
            print(players)
        except:
            print('Error!')
            client.close()
            break

def client_send():
    while True:
        # player
        player.update()
        player.draw(win,(255,255,255))
        client.send(pickle.dumps(player))

        # events
        for event in pygame.event.get():
            if event.type == QUIT:
                sys.exit()
        
        pygame.display.update()

receive_thread = threading.Thread(target=client_receive)
receive_thread.start()

send_thread = threading.Thread(target=client_send)
send_thread.start()